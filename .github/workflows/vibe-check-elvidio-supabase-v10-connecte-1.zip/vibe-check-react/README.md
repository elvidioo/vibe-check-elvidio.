# VIBE CHECK par Elvidio

Starter React + Vite mobile-first pour transformer la maquette en application web.

## Lancer le projet

1. Installe Node.js sur un ordinateur ou utilise un environnement de développement en ligne compatible Vite.
2. Décompresse le projet.
3. Copie `.env.example` vers `.env`.
4. Remplace les deux valeurs par l'URL Supabase et la clé publique `anon`/publishable du projet.
5. Dans un terminal, exécute :

```bash
npm install
npm run dev
```

Pour construire la version de production :

```bash
npm run build
```

## Supabase déjà attendu

Cette interface appelle les fonctions RPC existantes :
- `get_public_quiz({ p_slug: 'quiz-test-v1' })`
- `submit_public_quiz({ p_slug, p_participant_name, p_answers })`

Le format JSON exact de `get_public_quiz` doit correspondre à celui renvoyé par ta fonction SQL. Si les clés diffèrent, adapte le normalisateur dans `src/App.jsx`.

## Important

- N'ajoute jamais une clé `service_role` ou une clé secrète dans le frontend.
- Les données du classement et certains compteurs sont actuellement des données de démonstration.
- Les avatars sont des placeholders typographiques/emoji dans ce premier squelette. Les portraits 3D de la maquette pourront être ajoutés ensuite.
- La V1 fournit les écrans Accueil, Quiz, Classement, Profil et Paramètres, mais l'authentification et la création de quiz restent à implémenter.


## Connexion Supabase : étape V10

1. Dans Supabase, ouvre **Authentication → Providers** et active **Anonymous Sign-Ins** pour cette version de test.
2. Ouvre **SQL Editor**, puis exécute le fichier `supabase/migrations/20261014_vibe_player_system.sql` en entier.
3. Dans le projet, copie `.env.example` vers `.env` et renseigne `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` avec les valeurs publiques de ton projet.
4. Relance l'application. La session anonyme permet de conserver un portefeuille XP et un inventaire sur cet appareil/navigateur. Si les données du navigateur sont effacées, une session anonyme peut être perdue.

Cette migration ajoute les RPC `vibe_get_player_state`, `vibe_complete_daily_challenge`, `vibe_purchase_reward` et `vibe_get_leaderboard`. Elle ne remplace pas les fonctions existantes `get_public_quiz` et `submit_public_quiz`.

**Limites de cette étape :** l'authentification est anonyme, il n'y a pas encore de compte récupérable par email, et les missions quotidiennes doivent être durcies côté serveur avant un lancement public afin d'empêcher les appels frauduleux aux RPC de récompense. Les streams restent des aperçus et ne sont pas des diffusions vidéo réelles.
